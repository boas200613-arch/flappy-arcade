
import math
import random
import wave
import struct

# =====================================
# FLAPPY ARCADE - MODERN GAME MUSIC
# Original chill-house soundtrack
# =====================================

random.seed(42)

SAMPLE_RATE = 44100
BPM = 112
BARS = 16
BEAT = 60 / BPM
BAR = BEAT * 4
DURATION = BARS * BAR

OUTPUT = "flappy_arcade_game_music.wav"

def envelope(t, duration, attack=0.02, release=0.15):
    a = min(1, t / attack) if attack else 1
    r = min(1, (duration - t) / release) if release else 1
    return max(0, min(a, r))

def sine(freq, t):
    return math.sin(2 * math.pi * freq * t)

def pad(freq, t):
    # Warm layered synth pad
    return (
        sine(freq, t) * 0.55
        + sine(freq * 1.003, t) * 0.25
        + sine(freq * 2, t) * 0.12
        + sine(freq * 0.5, t) * 0.08
    )

def bass(freq, t):
    return (
        sine(freq, t) * 0.75
        + sine(freq * 2, t) * 0.25
    )

def kick(t):
    # Soft modern house kick
    freq = 45 + 90 * math.exp(-t * 30)
    return math.sin(2 * math.pi * freq * t) * math.exp(-t * 12)

def clap(t):
    if t < 0:
        return 0
    noise = random.uniform(-1, 1)
    return noise * math.exp(-t * 22) * 0.35

def hat(t):
    if t < 0:
        return 0
    noise = random.uniform(-1, 1)
    return noise * math.exp(-t * 65) * 0.12

def lead(freq, t):
    # Smooth modern pluck
    return (
        sine(freq, t) * 0.6
        + sine(freq * 2, t) * 0.2
        + sine(freq * 3, t) * 0.08
    )

# A minor / C major inspired progression
CHORDS = [
    [220.00, 261.63, 329.63],  # Am
    [174.61, 220.00, 261.63],  # F
    [130.81, 164.81, 196.00],  # C
    [196.00, 246.94, 293.66],  # G
]

BASS_NOTES = [55.00, 43.65, 32.70, 49.00]

# Catchy original melody
MELODY = [
    440.00, 523.25, 659.25, 523.25,
    392.00, 440.00, 523.25, 659.25,
    587.33, 523.25, 440.00, 392.00,
    440.00, 523.25, 587.33, 659.25
]

total_samples = int(DURATION * SAMPLE_RATE)
audio = []

print("Generating Flappy Arcade soundtrack...")

for i in range(total_samples):
    t = i / SAMPLE_RATE
    bar_index = int(t / BAR)
    beat_position = (t % BAR) / BEAT
    chord_index = bar_index % 4

    sample = 0.0

    # Chord pad
    chord = CHORDS[chord_index]
    pad_volume = 0.13

    for note in chord:
        sample += pad(note, t) * pad_volume

    # Deep bass on every beat
    beat_number = int(t / BEAT)
    beat_time = t % BEAT

    bass_freq = BASS_NOTES[chord_index]

    if beat_time < 0.35:
        sample += bass(bass_freq, beat_time) * (
            0.30 * envelope(beat_time, 0.35, 0.01, 0.15)
        )

    # Four-on-the-floor kick
    if beat_time < 0.25:
        sample += kick(beat_time) * 0.55

    # Clap on beats 2 and 4
    if beat_number % 4 in (1, 3):
        if beat_time < 0.15:
            sample += clap(beat_time) * 0.65

    # Modern hi-hats
    half_beat = beat_time % (BEAT / 2)
    if half_beat < 0.07:
        sample += hat(half_beat) * 0.75

    # Melody every second beat
    melody_step = int(t / (BEAT / 2))
    melody_index = melody_step % len(MELODY)
    melody_time = t % (BEAT / 2)

    if melody_time < 0.30:
        note = MELODY[melody_index]
        sample += lead(note, melody_time) * (
            0.15 * envelope(melody_time, 0.30, 0.01, 0.22)
        )

    # Gentle stereo-like movement through volume modulation
    sample *= 0.85 + 0.08 * math.sin(2 * math.pi * 0.15 * t)

    # Fade in and out
    fade_in = min(1, t / 2)
    fade_out = min(1, (DURATION - t) / 2)
    sample *= fade_in * fade_out

    # Soft clipping
    sample = math.tanh(sample * 1.4)

    audio.append(sample)

# Normalize
peak = max(abs(x) for x in audio)
audio = [x / peak * 0.85 for x in audio]

# Save WAV
with wave.open(OUTPUT, "wb") as wav:
    wav.setnchannels(1)
    wav.setsampwidth(2)
    wav.setframerate(SAMPLE_RATE)

    frames = bytearray()

    for sample in audio:
        value = int(sample * 32767)
        frames.extend(struct.pack("<h", value))

    wav.writeframes(frames)
print("--------------------------------")
print("SUCCESS!")
print("Created:", OUTPUT)
print("Duration:", round(DURATION, 1), "seconds")
print("BPM:", BPM)
print("--------------------------------")
